document.getElementById("screen1").style.display = "block";
document.getElementById("screen2").style.display = "none";
document.getElementById("screen3").style.display = "none";
document.getElementById("quizScreen").style.display = "none";
document.getElementById("resultScreen").style.display = "none";

function goToScreen2() {
  document.getElementById("screen1").style.display = "none";
  document.getElementById("screen2").style.display = "block";
}

function goToScreen3() {
  const name = document.getElementById("nameInput").value;
  if (name) {
    document.getElementById("screen2").style.display = "none";
    loadQuestion();
  } else {
    alert("გთხოვ, შეიყვანე სახელი!");
  }
}

const questions = [
  { question: "რომელი სეზონი მიყვარს ყველაზე მეტად?", answers: ["გაზაფხული", "შემოდგომა"], correctIndex: 0 },
  { question: "სად მირჩევნია მოგზაურობა?", answers: ["ზღვა", "მთები"], correctIndex: 1 },
  { question: "რომელი ფერი მიყვარს?", answers: ["ვარდისფერი", "ლურჯი"], correctIndex: 0 },
  { question: "რომელი ფილმი მიყვარს?", answers: ["Titanic", "პრინცესები ჰეჰ"], correctIndex: 1 },
  { question: "რომელი ცხოველი მირჩევნია?", answers: ["კატა", "ძაღლი"], correctIndex: 0 },
  { question: "დილის ადამიანი ვარ თუ ღამის?", answers: ["ღამის", "დილის"], correctIndex: 0 },
  { question: "რომელი მუსიკა მიტაცებს?", answers: ["შენი ხმა", "რამე"], correctIndex: 0 },
  { question: "ჩაი თუ ყავა?", answers: ["ჩაი", "ყავა"], correctIndex: 1 },
  { question: "რომელი ლოკაცია რომანტიკულია?", answers: ["ზღვა ღამით", "მთებში ვარსკვლავებით"], correctIndex: 1 },
  { question: "საყვარელი ფერი ტანსაცმელში?", answers: ["შავი", "თეთრი"], correctIndex: 0 },
  { question: "რას ვუყურებ როცა მოწყენილი ვარ?", answers: ["ანიმე", "ტიკტოკს"], correctIndex: 0 },
  { question: "რომელი ხილი მიყვარს?", answers: ["ბანანი", "მარწყვი"], correctIndex: 1 },
  { question: "საყვარელი დესერტი?", answers: ["ნუტელას ტორტი", "ჩიზქეიქი"], correctIndex: 0 },
  { question: "საყვარელი კომპლიმენტი შენგან?", answers: ["ყველა", "ჭკვიანი ხარ"], correctIndex: 0 },
  { question: "რომელია ჩემი საყვარელი ანიმე?", answers: ["ბერსერკი", "ტოკიო გოული"], correctIndex: 0 },
  { question: "ვინ უფრო იმპულსურად ყიდულობს ნივთებს?", answers: ["მახუნა", "ლიკუნა"], correctIndex: 1 },
  { question: "რომელია ჩემი საყვარელი საჭმელი?", answers: ["პიცა", "სუში"], correctIndex: 1 },
  { question: "რომელია ჩემი საყვარელი სახელი, რასაც შენ მეძახი?", answers: ["ღუნღიტო", "ჩემო პრინცესა"], correctIndex: 1 },
  { question: "ყველაფერი რომ დამღლელი ყოფილიყო ჩემთვის, სად წამიყვანდი?", answers: ["კაფე", "ორანჟერის"], correctIndex: 1 }
];

let currentQuestion = 0;
let score = 0;

function loadQuestion() {
  if (currentQuestion >= questions.length) {
    document.getElementById("quizScreen").style.display = "none";
    document.getElementById("resultScreen").style.display = "block";
    document.getElementById("resultScreen").innerHTML = `
      <h2>გილოცავ!</h2>
      <p style="font-size:24px;">ჩემო პუსკუ.</p>
      <p>შენ დააგროვე ${score} ქულა ${questions.length}-დან ❤️</p>
    `;
    return;
  }

  const q = questions[currentQuestion];
  document.getElementById("questionText").innerText = q.question;
  document.getElementById("btn1").innerText = q.answers[0];
  document.getElementById("btn2").innerText = q.answers[1];

  document.getElementById("quizScreen").style.display = "block";
  document.getElementById("resultScreen").style.display = "none";
}

function checkAnswer(index) {
  const correct = questions[currentQuestion].correctIndex;
  document.getElementById("quizScreen").style.display = "none";
  document.getElementById("resultScreen").style.display = "block";

  if (index === correct) {
    document.getElementById("emojiResult").innerText = "😊 სწორი პასუხი!";
    score++;
    document.getElementById("correctSound").play();
  } else {
    document.getElementById("emojiResult").innerText = "😠 არასწორია!";
    document.getElementById("wrongSound").play();
  }
}

function nextQuestion() {
  currentQuestion++;
  loadQuestion();
} 